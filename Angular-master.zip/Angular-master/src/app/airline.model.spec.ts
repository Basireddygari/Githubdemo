import { Airline } from './airline.model';

describe('Airline', () => {
  it('should create an instance', () => {
    expect(new Airline()).toBeTruthy();
  });
});
